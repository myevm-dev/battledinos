#!/usr/bin/env node
/**
 * Battle Dinos Genesis — deterministic inventory + pack manifest builder.
 *
 * Everything here is a pure function of (config, supply, rarity, element, name).
 * Same inputs -> byte-identical outputs -> same hash. No Math.random anywhere.
 *
 *   node build.js
 *
 * Outputs to ./out:
 *   cards.json     36,000-card inventory (33,300 standard + 2,700 specials)
 *   packs.json     7,200 sealed packs
 *   manifest.json  canonical hashed artifact (publish the hash BEFORE sales)
 *   summary.json   human-readable distribution report
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const OUT = path.join(__dirname, "out");
const RARITY_ORDER = ["Common", "Uncommon", "Rare", "Epic", "Legendary"];
const RANK = Object.fromEntries(RARITY_ORDER.map((r, i) => [r, i]));

/* ------------------------------------------------------------------ *
 * Deterministic PRNG: SHA-256 counter stream. Auditable in any language.
 * ------------------------------------------------------------------ */
function makeRng(seed) {
  let counter = 0;
  let pool = Buffer.alloc(0);
  let offset = 0;

  function refill() {
    pool = crypto
      .createHash("sha256")
      .update(seed)
      .update(String(counter++))
      .digest();
    offset = 0;
  }

  // Uniform integer in [0, n) via rejection sampling — no modulo bias.
  return function nextInt(n) {
    if (n <= 1) return 0;
    const bytes = Math.ceil(Math.log2(n) / 8) || 1;
    const limit = Math.floor(256 ** bytes / n) * n;
    for (;;) {
      if (offset + bytes > pool.length) refill();
      let v = 0;
      for (let i = 0; i < bytes; i++) v = v * 256 + pool[offset + i];
      offset += bytes;
      if (v < limit) return v % n;
    }
  };
}

function shuffle(arr, rng) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = rng(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/* ------------------------------------------------------------------ *
 * Largest-remainder apportionment. Guarantees the parts sum to `total`
 * exactly — no drift, no "we minted 601 holos".
 * ------------------------------------------------------------------ */
function apportion(weights, total) {
  const sum = weights.reduce((a, b) => a + b, 0);
  const exact = weights.map((w) => (w * total) / sum);
  const base = exact.map(Math.floor);
  let remaining = total - base.reduce((a, b) => a + b, 0);

  const order = exact
    .map((v, i) => ({ i, frac: v - Math.floor(v), w: weights[i] }))
    // Ties broken by weight then index so the result is fully deterministic.
    .sort((a, b) => b.frac - a.frac || b.w - a.w || a.i - b.i);

  for (let k = 0; k < remaining; k++) base[order[k % order.length].i]++;
  return base;
}

/* ------------------------------------------------------------------ *
 * Load + validate inputs
 * ------------------------------------------------------------------ */
function loadInputs() {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "config.json")));
  // Seed may be supplied via env so it never has to live in a committed file.
  if (process.env.BUILD_SEED) cfg.buildSeed = process.env.BUILD_SEED;

  /* editions_manifest.json is the SINGLE SOURCE OF TRUTH for the 33,300
   * standard editions. Everything about a base — name, rarity, element,
   * print run — is read from it. Nothing here is reconstructed, so the
   * standards can never silently drift from the file you maintain. */
  const editionsPath = path.join(__dirname, "data", "editions", "editions_manifest.json");
  if (!fs.existsSync(editionsPath)) {
    console.error(`\n  Missing ${editionsPath}\n  Copy your editions_manifest.json there and rerun.\n`);
    process.exit(1);
  }
  const editions = JSON.parse(fs.readFileSync(editionsPath));

  const errs = [];
  const supply = {}, rarity = {}, element = {}, name = {};
  const seenEdition = new Map();

  for (const c of editions) {
    const b = c.base_id;
    if (c.finish !== "standard") errs.push(`token ${c.token_id}: expected finish "standard", got "${c.finish}"`);

    // Per-base fields must never contradict across that base's editions.
    for (const [field, store] of [["rarity", rarity], ["element", element], ["name", name]]) {
      if (store[b] === undefined) store[b] = c[field];
      else if (store[b] !== c[field]) errs.push(`base ${b}: conflicting ${field} ("${store[b]}" vs "${c[field]}")`);
    }
    if (!RANK.hasOwnProperty(c.rarity)) errs.push(`base ${b}: unknown rarity "${c.rarity}"`);

    supply[b] = (supply[b] || 0) + 1;
    const key = `${b}|${c.edition}`;
    if (seenEdition.has(key)) errs.push(`base ${b}: edition ${c.edition} appears twice`);
    seenEdition.set(key, true);
  }

  const bases = Object.keys(supply).map(Number).sort((a, b) => a - b);

  // token_id must be 1..N with no gaps — specials are appended after it.
  const ids = editions.map((c) => c.token_id);
  const contiguous = ids.length === new Set(ids).size &&
    Math.min(...ids) === 1 && Math.max(...ids) === ids.length;
  if (!contiguous) errs.push("token_id in editions_manifest.json is not a contiguous 1..N range");

  // edition numbers must run 1..supply within each base, and edition_supply must agree.
  for (const b of bases) {
    for (let e = 1; e <= supply[b]; e++) {
      if (!seenEdition.has(`${b}|${e}`)) { errs.push(`base ${b}: missing edition ${e}`); break; }
    }
  }
  for (const c of editions) {
    if (c.edition_supply !== supply[c.base_id]) {
      errs.push(`token ${c.token_id}: edition_supply ${c.edition_supply} != actual ${supply[c.base_id]}`);
      break;
    }
  }

  /* Optional cross-check. supply.json is no longer an input — it is kept
   * only so a mismatch surfaces loudly if the editions file is replaced. */
  const supplyPath = path.join(__dirname, "data", "supply.json");
  if (fs.existsSync(supplyPath)) {
    const expected = JSON.parse(fs.readFileSync(supplyPath));
    const drift = bases.filter((b) => expected[b] !== undefined && expected[b] !== supply[b]);
    if (drift.length) {
      errs.push(`supply.json disagrees with editions_manifest.json for base(s) ${drift.slice(0, 5).join(", ")}` +
        `${drift.length > 5 ? ` (+${drift.length - 5} more)` : ""}`);
    }
  }

  const stdTotal = editions.length;
  const specTotal = Object.values(cfg.finishes).reduce((a, b) => a + b, 0);
  const target = cfg.packs * cfg.cardsPerPack;
  if (stdTotal + specTotal !== target) {
    errs.push(`${stdTotal} standard + ${specTotal} special = ${stdTotal + specTotal}, need ${target}`);
  }
  if (cfg.allocation.altArt === "one_per_base" && cfg.finishes.alt_art !== bases.length) {
    errs.push(`alt_art ${cfg.finishes.alt_art} != ${bases.length} bases (one_per_base mode)`);
  }
  if (cfg.buildSeed.includes("REPLACE")) {
    console.warn("\n  \x1b[33m! buildSeed is still the placeholder. Replace it before production.\x1b[0m");
  }
  if (errs.length) {
    console.error("\nINPUT VALIDATION FAILED:\n" + errs.slice(0, 20).map((e) => "  - " + e).join("\n") + "\n");
    process.exit(1);
  }

  console.log(`\n  read ${stdTotal.toLocaleString()} standard editions across ${bases.length} bases from editions_manifest.json`);
  return { cfg, editions, supply, rarity, element, name, bases, stdTotal, specTotal };
}

/* ------------------------------------------------------------------ *
 * Phase 1 — build the 36,000-card inventory
 * ------------------------------------------------------------------ */
function buildInventory(inp) {
  const { cfg, supply, rarity, element, name, bases } = inp;
  const cards = [];
  let tokenId = 1;

  const card = (baseId, edition, editionSupply, finish) => ({
    token_id: tokenId++,
    base_id: baseId,
    name: name[baseId],
    edition,
    edition_supply: editionSupply,
    rarity: rarity[baseId],
    element: element[baseId],
    finish,
  });

  /* --- Standards: copied straight through from editions_manifest.json.
   * Field order is normalised so the canonical hash is stable, but no value
   * is recomputed. token_id, edition, and edition_supply are yours. */
  for (const c of inp.editions) {
    cards.push({
      token_id: c.token_id,
      base_id: c.base_id,
      name: c.name,
      edition: c.edition,
      edition_supply: c.edition_supply,
      rarity: c.rarity,
      element: c.element,
      finish: "standard",
    });
  }
  tokenId = inp.editions.length + 1; // specials continue from here

  // --- Specials: token_id 33301..36000, own edition namespace per finish.
  const weightsFor = (mode) => {
    if (mode === "flat") return bases.map(() => 1);              // equal per base
    if (mode === "sqrt") return bases.map((b) => Math.sqrt(supply[b])); // middle ground
    return bases.map((b) => supply[b]);                          // proportional
  };

  /* Optional floor: guarantee N copies to every base in the listed tiers,
   * then apportion the remainder normally. Without this, rounding can wipe a
   * whole tier out of a finish — 600 holos over 333 bases leaves each
   * Legendary base entitled to ~0.3, which floors to zero. */
  const withFloor = (mode, total, floorCfg) => {
    const tiers = (floorCfg && floorCfg.tiers) || [];
    const per = (floorCfg && floorCfg.perBase) || 0;
    if (!per || !tiers.length) return apportion(weightsFor(mode), total);

    const floored = bases.map((b) => (tiers.includes(rarity[b]) ? per : 0));
    const reserved = floored.reduce((a, c) => a + c, 0);
    if (reserved > total) throw new Error(`floor reserves ${reserved} > ${total} available`);

    // Bases receiving a floor are excluded from the remainder pool so they
    // don't get counted twice.
    const pool = bases.map((b, i) => (floored[i] ? 0 : weightsFor(mode)[i]));
    const rest = apportion(pool, total - reserved);
    return bases.map((_, i) => floored[i] + rest[i]);
  };

  const alloc = {
    alt_art:
      cfg.allocation.altArt === "one_per_base"
        ? bases.map(() => 1)
        : apportion(weightsFor(cfg.allocation.altArt), cfg.finishes.alt_art),
    holo: withFloor(cfg.allocation.holo, cfg.finishes.holo, cfg.allocation.holoFloor),
    reverse_holo: withFloor(cfg.allocation.reverseHolo, cfg.finishes.reverse_holo, cfg.allocation.reverseHoloFloor),
  };

  // Ordered coarse -> fine so the rarest finish gets the highest token_ids.
  for (const finish of ["reverse_holo", "holo", "alt_art"]) {
    bases.forEach((b, i) => {
      const n = alloc[finish][i];
      for (let e = 1; e <= n; e++) cards.push(card(b, e, n, finish));
    });
  }

  return { cards, alloc };
}

/* ------------------------------------------------------------------ *
 * Phase 2 — deal 36,000 cards into 7,200 packs under hard constraints
 * ------------------------------------------------------------------ */
function buildPacks(cards, cfg, rng) {
  const { packs: NPACKS, cardsPerPack: K, packRules: R } = cfg;
  const byId = new Map(cards.map((c) => [c.token_id, c]));
  const isStd = (id) => byId.get(id).finish === "standard";
  const isStrong = (id) => RANK[byId.get(id).rarity] >= 1; // Uncommon or better

  const specials = shuffle(cards.filter((c) => c.finish !== "standard").map((c) => c.token_id), rng);
  if (R.maxSpecialsPerPack === 1 && specials.length > NPACKS) {
    throw new Error(`${specials.length} specials > ${NPACKS} packs with maxSpecialsPerPack=1`);
  }

  const packs = Array.from({ length: NPACKS }, () => []);

  /* -- Step 1: at most one special per pack ------------------------- */
  specials.forEach((id, i) => packs[i].push(id));

  /* -- Step 2: satisfy the Uncommon+ floor CONSTRUCTIVELY -----------
   * Reserve strong standards for the packs that need them, instead of
   * dealing randomly and hoping repair can dig us out.
   * ----------------------------------------------------------------- */
  const strongStd = shuffle(cards.filter((c) => c.finish === "standard" && RANK[c.rarity] >= 1).map((c) => c.token_id), rng);
  const commonStd = shuffle(cards.filter((c) => c.finish === "standard" && RANK[c.rarity] === 0).map((c) => c.token_id), rng);

  const need = R.minUncommonOrBetterPerPack || 0;
  let sIdx = 0;
  for (const p of packs) {
    let have = p.filter(isStrong).length;
    while (have < need && p.length < K) {
      if (sIdx >= strongStd.length) throw new Error("not enough Uncommon+ cards for the floor");
      p.push(strongStd[sIdx++]);
      have++;
    }
  }

  /* -- Step 3: fill remaining slots from what's left ----------------- */
  const rest = shuffle(strongStd.slice(sIdx).concat(commonStd), rng);
  let rIdx = 0;
  for (const p of packs) while (p.length < K) p.push(rest[rIdx++]);
  if (rIdx !== rest.length) throw new Error(`${rest.length - rIdx} cards left undealt`);

  /* -- Step 4: repair duplicate bases with a SCORED accept rule ------
   * Score = number of duplicate base_ids in a pack. A swap is kept when
   * the combined score of the two packs strictly decreases, so partial
   * progress is preserved and the loop actually converges.
   * ----------------------------------------------------------------- */
  const dupScore = (p) => {
    const seen = new Set();
    let d = 0;
    for (const id of p) {
      const b = byId.get(id).base_id;
      if (seen.has(b)) d++;
      else seen.add(b);
    }
    return d;
  };
  const floorOk = (p) => p.filter(isStrong).length >= need;

  const stats = { passes: 0, swaps: 0, residualDupPacks: 0 };

  if (R.noDuplicateBaseInPack) {
    for (let pass = 0; pass < 60; pass++) {
      const broken = [];
      for (let i = 0; i < NPACKS; i++) if (dupScore(packs[i]) > 0) broken.push(i);
      stats.passes = pass + 1;
      if (!broken.length) break;

      for (const pi of broken) {
        const p = packs[pi];
        for (let attempt = 0; attempt < 250 && dupScore(p) > 0; attempt++) {
          // Pick a slot holding a duplicated base (standards only — never
          // move a special, or the one-per-pack invariant breaks).
          const seen = new Set();
          let si = -1;
          for (let i = 0; i < p.length; i++) {
            const b = byId.get(p[i]).base_id;
            if (seen.has(b) && isStd(p[i])) { si = i; break; }
            seen.add(b);
          }
          if (si < 0) break;

          const qi = rng(NPACKS);
          if (qi === pi) continue;
          const q = packs[qi];
          const qj = q.findIndex((id) => isStd(id));
          if (qj < 0) continue;

          const before = dupScore(p) + dupScore(q);
          const a = p[si], b = q[qj];
          p[si] = b; q[qj] = a;
          if (dupScore(p) + dupScore(q) < before && floorOk(p) && floorOk(q)) {
            stats.swaps++;
          } else {
            p[si] = a; q[qj] = b;
          }
        }
      }
    }
    stats.residualDupPacks = packs.filter((p) => dupScore(p) > 0).length;
  }

  shuffle(packs, rng); // so special-bearing packs aren't the low indices
  return {
    packs: packs.map((ids, i) => ({ pack_id: i + 1, cards: ids.slice().sort((x, y) => x - y) })),
    stats,
  };
}

/* ------------------------------------------------------------------ *
 * Phase 3 — report + canonical hash
 * ------------------------------------------------------------------ */
function summarize(cards, packs, alloc, bases, rarity, supply) {
  const byId = new Map(cards.map((c) => [c.token_id, c]));
  const count = (arr, key) =>
    arr.reduce((m, c) => ((m[c[key]] = (m[c[key]] || 0) + 1), m), {});

  const grid = {};
  for (const r of RARITY_ORDER) grid[r] = { standard: 0, reverse_holo: 0, holo: 0, alt_art: 0, total: 0 };
  for (const c of cards) { grid[c.rarity][c.finish]++; grid[c.rarity].total++; }

  const packHas = (p, fn) => p.cards.some((id) => fn(byId.get(id)));
  const pct = (n) => +((n / packs.length) * 100).toFixed(3);

  const pullRates = {
    by_finish: {},
    by_rarity: {},
    any_special: pct(packs.filter((p) => packHas(p, (c) => c.finish !== "standard")).length),
  };
  for (const f of ["standard", "reverse_holo", "holo", "alt_art"]) {
    const n = packs.filter((p) => packHas(p, (c) => c.finish === f)).length;
    pullRates.by_finish[f] = {
      cards: cards.filter((c) => c.finish === f).length,
      pct_of_packs: pct(n),
      one_in_packs: n ? +(packs.length / n).toFixed(1) : null,
    };
  }
  for (const r of RARITY_ORDER) {
    const n = packs.filter((p) => packHas(p, (c) => c.rarity === r)).length;
    pullRates.by_rarity[r] = {
      cards: grid[r].total,
      pct_of_packs: pct(n),
      one_in_packs: n ? +(packs.length / n).toFixed(1) : null,
    };
  }

  // Top chase: legendary alt arts
  const chase = cards
    .filter((c) => c.rarity === "Legendary" && c.finish === "alt_art")
    .map((c) => ({ token_id: c.token_id, base_id: c.base_id, name: c.name, standard_supply: supply[c.base_id] }));

  /* ui: everything the odds table renders, pre-shaped. The frontend should
   * never derive a number — that is how a published page drifts from the
   * manifest it claims to describe. */
  const FIN = ["standard", "reverse_holo", "holo", "alt_art"];
  const ui = {
    total_cards: cards.length,
    total_packs: packs.length,
    cards_per_pack: packs[0].cards.length,
    finishes: FIN.map((key) => ({
      key,
      label: { standard: "Standard", reverse_holo: "Reverse Holo", holo: "Holo", alt_art: "Alt Art 1/1" }[key],
      cards: pullRates.by_finish[key].cards,
      one_in_packs: pullRates.by_finish[key].one_in_packs,
    })),
    tiers: RARITY_ORDER.map((label) => ({
      label,
      cells: Object.fromEntries(FIN.map((f) => [f, grid[label][f]])),
      total: grid[label].total,
      one_in_packs: pullRates.by_rarity[label].one_in_packs,
    })),
    any_special_pct: pullRates.any_special,
  };

  return { totals: count(cards, "finish"), grid, pullRates, chase, ui };
}

function canonical(v) {
  if (Array.isArray(v)) return "[" + v.map(canonical).join(",") + "]";
  if (v && typeof v === "object")
    return "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + canonical(v[k])).join(",") + "}";
  return JSON.stringify(v);
}
const sha = (s) => "0x" + crypto.createHash("sha256").update(s).digest("hex");

/* ------------------------------------------------------------------ */
function main() {
  const inp = loadInputs();
  const { cfg, bases, rarity, supply } = inp;
  const rng = makeRng(cfg.buildSeed);

  const { cards, alloc } = buildInventory(inp);
  if (cards.length !== cfg.packs * cfg.cardsPerPack) {
    throw new Error(`built ${cards.length} cards, expected ${cfg.packs * cfg.cardsPerPack}`);
  }

  const { packs, stats } = buildPacks(cards, cfg, rng);

  // Every card dealt exactly once — the invariant that matters most.
  const dealt = new Set(packs.flatMap((p) => p.cards));
  if (dealt.size !== cards.length) throw new Error(`dealt ${dealt.size} distinct, expected ${cards.length}`);

  const summary = summarize(cards, packs, alloc, bases, rarity, supply);

  const manifest = {
    collection: cfg.collection,
    version: cfg.version,
    build_seed: cfg.buildSeed,
    total_cards: cards.length,
    total_packs: packs.length,
    cards_hash: sha(canonical(cards)),
    packs_hash: sha(canonical(packs)),
  };
  manifest.manifest_hash = sha(canonical(manifest));

  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, "cards.json"), JSON.stringify(cards));
  fs.writeFileSync(path.join(OUT, "packs.json"), JSON.stringify(packs));
  fs.writeFileSync(path.join(OUT, "manifest.json"), JSON.stringify(manifest, null, 2));
  fs.writeFileSync(path.join(OUT, "summary.json"), JSON.stringify(summary, null, 2));

  /* ---- console report ---- */
  const g = summary.grid;
  console.log(`\n  ${cards.length.toLocaleString()} cards -> ${packs.length.toLocaleString()} packs`);
  console.log(`  repair: ${stats.passes} passes, ${stats.swaps} swaps, ${stats.residualDupPacks} packs still holding a duplicate base\n`);

  console.log("  TIER x FINISH");
  console.log("  " + "tier".padEnd(11) + "std".padStart(7) + "revholo".padStart(9) + "holo".padStart(7) + "alt".padStart(6) + "total".padStart(8));
  for (const r of RARITY_ORDER) {
    console.log("  " + r.padEnd(11) + String(g[r].standard).padStart(7) + String(g[r].reverse_holo).padStart(9) +
      String(g[r].holo).padStart(7) + String(g[r].alt_art).padStart(6) + String(g[r].total).padStart(8));
  }

  console.log("\n  PULL RATES (per pack of " + cfg.cardsPerPack + ")");
  for (const r of RARITY_ORDER) {
    const v = summary.pullRates.by_rarity[r];
    console.log(`    ${r.padEnd(11)} ${String(v.cards).padStart(6)} cards  ${String(v.pct_of_packs).padStart(7)}%  1 in ${v.one_in_packs}`);
  }
  for (const [f, v] of Object.entries(summary.pullRates.by_finish)) {
    console.log(`    ${f.padEnd(11)} ${String(v.cards).padStart(6)} cards  ${String(v.pct_of_packs).padStart(7)}%  1 in ${(packs.length / (v.pct_of_packs / 100 * packs.length)).toFixed(1)}`);
  }
  console.log(`    ${"any special".padEnd(11)} ${String(2700).padStart(6)} cards  ${String(summary.pullRates.any_special).padStart(7)}%`);

  console.log("\n  TOP CHASE (Legendary Alt Art 1/1)");
  for (const c of summary.chase) {
    console.log(`    #${String(c.token_id).padEnd(6)} ${c.name.padEnd(16)} base ${String(c.base_id).padEnd(4)} (${c.standard_supply} standard)`);
  }

  console.log("\n  PUBLISH THIS BEFORE SALES OPEN:");
  console.log("    manifest_hash " + manifest.manifest_hash);
  console.log("    cards_hash    " + manifest.cards_hash);
  console.log("    packs_hash    " + manifest.packs_hash + "\n");
}

main();
