# Battle Dinos Genesis — Pack Manifest

Deterministic generator and frozen artifacts for the Genesis Series: **36,000 cards sealed into 7,200 packs of 5**.

This package contains the completed card inventory, the completed pack manifest, a cryptographic commitment to both, and a standalone verifier. It is **finished work**. The app consumes it. The app does not regenerate it.

```
manifest_hash  0xae9cb4623520478c89f2a1e74fa584e82fe70fb89cc5d29f8130b563efe0a8f6
```

---

## Read this first

**`editions_manifest.json` is the source of truth.** `build.js` reads your
33,300 standard editions straight out of it and copies them through
unchanged — nothing about a base is reconstructed or inferred. Replace that
file and rebuild, and the standards follow automatically. The build fails
loudly on contradictory rarity/element/name within a base, a non-contiguous
`token_id` range, gaps in edition numbering, or a wrong `edition_supply`.

**`build.js` never runs in the app.** It is offline tooling. It ran once, produced `out/`, and those files are now frozen. If the running application can regenerate packs, the published hash stops being a commitment and becomes a suggestion. Treat `out/*.json` as read-only data assets, exactly like images.

**`out/packs.json` and `out/cards.json` are secret until sellout.** They contain the full contents of every pack. Publishing either one early lets buyers cherry-pick. See [The reveal ceremony](#the-reveal-ceremony).

**`config.json` + the build seed also reveal everything.** The build is deterministic, so anyone holding the seed and the (public) input data can regenerate all 7,200 packs. The seed reads from `process.env.BUILD_SEED`. Keep it out of git.

---

## Why packs are pre-built

The naive design — draw 5 random cards when a pack is opened — breaks in three ways this design avoids.

**Supply drift.** Rolling independent probabilities per card gives you *expected* 333 alt arts, not exactly 333. Pre-building guarantees exact counts because the cards are dealt, not rolled.

**Reroll attacks.** On-chain randomness derived from `block.timestamp`, `blockhash`, or a hash of the caller lets a buyer simulate the open in a contract and revert unless they draw a chase card. Free rerolls, unlimited attempts. Pre-built packs have nothing to reroll — the contents were fixed before anyone bought anything.

**Card counting.** With 36,000 cards dealt from a shrinking pool, late buyers can track what's been minted and compute exactly what remains. The last pack would have zero randomness — its five cards would be public knowledge. Under this design nothing resolves until every pack is sold, so pack #7,200 is as unknown as pack #1.

The single random input is a global offset applied at reveal. One number secures all 7,200 assignments.

---

## What's in the box

```
battle-dinos-packs/
├─ README.md              this file
├─ package.json           npm scripts
├─ .gitignore             keeps secrets out of git
├─ types.ts               TypeScript types for the artifacts
│
├─ build.js               offline generator — DO NOT run in the app
├─ verify.js              standalone verifier — safe anywhere
├─ config.json            build settings
│
├─ data/
│  ├─ editions/
│  │  └─ editions_manifest.json   SOURCE OF TRUTH — your 33,300 standards
│  └─ supply.json                 optional cross-check only
│
└─ out/                   generated artifacts
   ├─ manifest.json       PUBLIC — the hash commitment
   ├─ summary.json        PUBLIC — pull rates and distribution
   ├─ cards.json          SECRET until reveal (5.1 MB)
   └─ packs.json          SECRET until reveal (398 KB)
```

---

## The set

**36,000 cards** = 33,300 standard + 1,767 reverse holo + 600 holo + 333 alt art
**7,200 packs** × 5 cards

Token IDs 1–33,300 are the standard editions and are **byte-identical to the pre-existing `editions_manifest.json`** — same token_id, same base_id, same edition number. Specials occupy 33,301–36,000 and use their own edition namespace per finish, so a holo is `Holo 2 of 2`, not a re-skin of standard #109.

### Tier × finish

| Tier | Standard | Rev Holo | Holo | Alt Art | Total |
|---|---|---|---|---|---|
| Common | 21,646 | 1,142 | 384 | 167 | 23,339 |
| Uncommon | 7,903 | 423 | 138 | 83 | 8,547 |
| Rare | 2,942 | 160 | 56 | 50 | 3,208 |
| Epic | 708 | 37 | 14 | 25 | 784 |
| Legendary | 101 | 5 | 8 | 8 | 122 |

### Pull rates (per pack of 5)

| | P(≥1 in a pack) | 1 in N packs |
|---|---|---|
| Common | 99.9% | ~every pack |
| Uncommon | 81.4% | 1.2 |
| Rare | 38.9% | 2.6 |
| Epic | 10.5% | 9.5 |
| **Legendary** | **1.6%** | **63** |
| Reverse Holo | 24.5% | 4.1 |
| Holo | 8.3% | 12.0 |
| Alt Art 1/1 | 4.6% | 21.6 |
| Any special | 37.5% | 2.7 |

Publish these before sales open. `out/summary.json` is machine-readable and is the source of truth for the odds page.

### Top chase — Legendary Alt Art 1/1

Eight cards across 7,200 packs, roughly **1 in 900**.

| token_id | Name | base_id | Standard supply |
|---|---|---|---|
| 35780 | **Emberreaver** | 113 | **3** |
| 35721 | Pyrecrusher | 54 | 5 |
| 35742 | Mossfang | 75 | 7 |
| 35796 | Riftmauler | 129 | 15 |
| 35881 | Ghosthunter | 214 | 15 |
| 35929 | Apexjaw | 262 | 18 |
| 35891 | Flinttalon | 224 | 19 |
| 35992 | Azurejaw | 325 | 19 |

Emberreaver exists as **4 cards total** — 3 standard, 1 alt art. It is the best card in the set.

### Guarantees enforced in every pack

- Exactly 5 cards
- No duplicate `base_id`
- At most one special finish
- At least one Uncommon-or-better

That last rule eliminates the ~11% of packs that would otherwise have been five Commons.

---

## Integrating into the app

### File placement

```
battle-ui/public/genesis/
├─ manifest.json     copy now
├─ summary.json      copy now
├─ packs.json        copy AT REVEAL ONLY
└─ cards.json        copy AT REVEAL ONLY
```

Two separate npm scripts, deliberately:

```bash
npm run packs:publish   # manifest + summary — safe today
npm run packs:reveal    # cards + packs — one-time, after sellout
```

### Resolving a pack

After reveal, this is pure arithmetic. No randomness, no VRF, no async.

```ts
import type { Pack, Card } from "./types";

const OFFSET = 4173; // from the NIST pulse, published at reveal

export function resolvePack(purchaseIndex: number, packs: Pack[], cards: Card[]): Card[] {
  const byId = new Map(cards.map(c => [c.token_id, c]));
  const packId = ((purchaseIndex + OFFSET) % 7200) + 1;
  const pack = packs.find(p => p.pack_id === packId)!;
  return pack.cards.map(id => byId.get(id)!);
}
```

`purchaseIndex` is 0-based mint order. Build the `byId` map once at module scope, not per call.

### Suggested routes

| Route | When | Reads |
|---|---|---|
| `/odds` | before sales | `summary.json` |
| `/packs` | during sales | `manifest.json` (hash display only) |
| `/packs/[id]` | after reveal | `packs.json` + `cards.json` |
| `/verify` | after reveal | all four |

### Browser verifier

Port `verify.js` to a client component using `crypto.subtle.digest('SHA-256', ...)`. Keep `canonical()` **byte-identical** — key ordering and separators both matter, or the hash won't reproduce. Letting buyers verify in-browser instead of cloning a repo is worth the hour.

---

## The reveal ceremony

1. **Before sales.** Publish `manifest_hash` somewhere timestamped and immutable — on-chain is best. Publish `summary.json` as the odds page. Commit to an exact `revealTimestamp` at the same time.
2. **During sales.** Record each buyer's `purchaseIndex`. Reveal nothing.
3. **At sellout.** Pull the NIST beacon pulse **at the pre-committed timestamp**. `offset = pulse % 7200`.
4. **Publish.** `cards.json`, `packs.json`, the pulse (with its NIST signature), and the offset.
5. **Anyone verifies.** `node verify.js 0xed81a7...`

**The pre-committed timestamp is load-bearing.** If whoever posts the pulse can see it, dislike the offset, and wait 60 seconds for the next one, the system is rigged with extra steps. Selective abort is the only real attack on beacon randomness, and pre-committing the exact pulse index closes it. The contract or backend must reject any pulse that isn't from that index.

---

## Running the tools

```bash
npm run packs:build     # regenerate (offline only)
npm run packs:verify    # check artifacts
node verify.js 0xae9cb4623520478c89f2a1e74fa584e82fe70fb89cc5d29f8130b563efe0a8f6
```

`verify.js` re-derives the hash and independently re-checks every supply and constraint claim. It does not import `build.js`, so a rigged builder cannot produce a set that passes.

Expected output: **20 checks, all passing.**

### Determinism

Same seed + same inputs → byte-identical output. Verified by rebuilding and diffing the hash. The PRNG is a SHA-256 counter stream with rejection sampling (no modulo bias) — reimplementable in any language. `Math.random()` appears nowhere.

### Regenerating

**Rebuilding with a different seed reshuffles every pack and changes the hash.** If you rebuild after publishing the hash, you have invalidated your commitment. Don't.

```bash
BUILD_SEED="your-real-secret-seed" npm run packs:build
```

`build.js` warns loudly while the placeholder seed is still in place.

---

## Open decisions

### 1. Set the real build seed — required

`config.json` still holds `battle-dinos-genesis-v1-REPLACE-BEFORE-PRODUCTION`. Set `BUILD_SEED` in `.env`, rebuild, and **only then** publish the hash. All hashes in this README correspond to the placeholder seed and will change.

### 2. Special-finish allocation — resolved, but revisit if you like

Holo and reverse holo are apportioned in proportion to each base's print run.
Left alone, rounding erased an entire tier: 600 holos over 333 bases entitles
each Legendary base to ~0.3, which floors to zero. `allocation.holoFloor`
now guarantees one holo per Legendary base before the remainder is
apportioned, so the tier reads 5 RH / 8 holo / 8 alt.

Legendary reverse holo is still the scarcest Legendary finish at 5. Add
`reverseHoloFloor: { tiers: ["Legendary"], perBase: 2 }` if you want a clean
descending ladder. `allocation.holo` also accepts `sqrt` or `flat` if you
want a different overall shape.

### 3. 62.5% of packs contain no special finish

2,700 specials across 7,200 packs. Modern TCG buyers expect a guaranteed reverse holo in every pack. Your base cards carry real utility (genetics, battle stats, progression), which makes this more defensible than a pure art set — but it's well below expectation. Raising `finishes.reverse_holo` to ~3,600 makes it 1 in 2. One number in `config.json`, then rebuild.

### 4. Artwork does not exist yet

`cards.json` has no `image` field, by design — the manifest is complete and correct without it. But:

- **333 alt arts** need original artwork. That's 333 generations on the critical path.
- **Holo and reverse holo** need visually distinct treatments, or the finish is a metadata label with nothing to show.

Add `image` at render time by convention (`ipfs://CID/{finish}/{base_id}.png`) rather than baking paths into `cards.json` — otherwise the hash changes and the commitment breaks.

### 5. Secrecy model

Two coherent options. Pick one and be consistent.

**Sealed.** Keep `packs.json`, `cards.json`, and the seed private until reveal. Preserves the sealed-box feeling. Requires operational discipline — one leaked file spoils the set.

**Fully open.** Publish everything up front, including the seed and both artifacts. Buyers verify the distribution is fair *before* spending money instead of trusting you until reveal. Mystery is preserved entirely by the NIST offset, which nobody knows including you. Nothing to leak.

Fully open is the more trustworthy model. The only cost is the unknown-distribution feeling.

---

## Data schemas

### `out/cards.json` — 36,000 entries

```json
{
  "token_id": 35780,
  "base_id": 113,
  "name": "Emberreaver",
  "edition": 1,
  "edition_supply": 1,
  "rarity": "Legendary",
  "element": "Primal",
  "finish": "alt_art"
}
```

`finish` ∈ `"standard" | "reverse_holo" | "holo" | "alt_art"`
`rarity` ∈ `"Common" | "Uncommon" | "Rare" | "Epic" | "Legendary"`
`edition` runs 1..`edition_supply` within each `(base_id, finish)` group.

### `out/packs.json` — 7,200 entries

```json
{ "pack_id": 1, "cards": [842, 5511, 19203, 24880, 35780] }
```

`cards` holds 5 `token_id`s, ascending. `pack_id` is 1-based.

### `out/manifest.json`

```json
{
  "collection": "Battle Dinos Genesis",
  "version": "genesis-packs-v1",
  "build_seed": "...",
  "total_cards": 36000,
  "total_packs": 7200,
  "cards_hash": "0x...",
  "packs_hash": "0x...",
  "manifest_hash": "0x..."
}
```

`manifest_hash` is the SHA-256 of the canonical serialization of the other fields. It is the single value to publish.

---

## Invariants — never break these

1. `build.js` does not run in the application.
2. `out/*.json` are read-only assets. Never mutate, sort, or re-serialize them — canonical byte order is what the hash commits to.
3. `token_id` 1–33,300 must stay aligned with the existing `editions_manifest.json`.
4. Rebuilding after publishing the hash invalidates the commitment.
5. The NIST offset stays unknown until sellout. That is the only load-bearing secret in the fully-open model.
