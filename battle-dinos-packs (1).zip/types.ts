/**
 * Battle Dinos Genesis — types for the frozen pack artifacts.
 *
 * Copy into battle-ui (e.g. types/genesis.ts). These describe read-only data
 * assets; nothing here should ever be constructed or mutated at runtime.
 */

export type Rarity = "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary";
export type Finish = "standard" | "reverse_holo" | "holo" | "alt_art";

export const RARITY_ORDER: readonly Rarity[] = [
  "Common",
  "Uncommon",
  "Rare",
  "Epic",
  "Legendary",
] as const;

/** One of the 36,000 cards. `out/cards.json` is `Card[]`. */
export interface Card {
  /** 1–33,300 standard (matches editions_manifest.json), 33,301–36,000 special. */
  token_id: number;
  /** 1–333. */
  base_id: number;
  name: string;
  /** 1..edition_supply within this (base_id, finish) group. */
  edition: number;
  edition_supply: number;
  rarity: Rarity;
  element: string;
  finish: Finish;
}

/** One of the 7,200 sealed packs. `out/packs.json` is `Pack[]`. */
export interface Pack {
  /** 1-based. */
  pack_id: number;
  /** Exactly 5 token_ids, ascending. */
  cards: number[];
}

/** `out/manifest.json` — publish `manifest_hash` before sales open. */
export interface Manifest {
  collection: string;
  version: string;
  build_seed: string;
  total_cards: number;
  total_packs: number;
  cards_hash: `0x${string}`;
  packs_hash: `0x${string}`;
  manifest_hash: `0x${string}`;
}

/** `out/summary.json` — the source of truth for the odds page. */
export interface Summary {
  totals: Record<Finish, number>;
  grid: Record<Rarity, Record<Finish | "total", number>>;
  pullRates: {
    by_finish: Record<string, { cards: number; pct_of_packs: number }>;
    by_rarity: Record<
      Rarity,
      { cards: number; pct_of_packs: number; one_in_packs: number | null }
    >;
    any_special: number;
  };
  chase: Array<{
    token_id: number;
    base_id: number;
    name: string;
    standard_supply: number;
  }>;
}

/* ------------------------------------------------------------------ *
 * Pack resolution
 *
 * Deterministic and synchronous. The only random input to the entire
 * system is `offset`, drawn from a NIST beacon pulse at a timestamp
 * committed to before sales opened.
 * ------------------------------------------------------------------ */

export const TOTAL_PACKS = 7200;
export const CARDS_PER_PACK = 5;

/** Which pack a buyer receives. `purchaseIndex` is 0-based mint order. */
export function packIdFor(purchaseIndex: number, offset: number): number {
  return ((purchaseIndex + offset) % TOTAL_PACKS) + 1;
}

/**
 * Build once at module scope — not per render, not per call.
 * cards.json is ~5 MB; re-indexing it repeatedly will stall the UI.
 */
export function indexCards(cards: Card[]): Map<number, Card> {
  return new Map(cards.map((c) => [c.token_id, c]));
}

export function indexPacks(packs: Pack[]): Map<number, Pack> {
  return new Map(packs.map((p) => [p.pack_id, p]));
}

export function resolvePack(
  purchaseIndex: number,
  offset: number,
  packIndex: Map<number, Pack>,
  cardIndex: Map<number, Card>
): Card[] {
  const pack = packIndex.get(packIdFor(purchaseIndex, offset));
  if (!pack) throw new Error(`pack not found for purchaseIndex ${purchaseIndex}`);
  return pack.cards.map((id) => {
    const card = cardIndex.get(id);
    if (!card) throw new Error(`card ${id} missing from cards.json`);
    return card;
  });
}

/* ------------------------------------------------------------------ *
 * Display helpers
 * ------------------------------------------------------------------ */

export const isSpecial = (c: Card): boolean => c.finish !== "standard";

/** True for the eight Legendary Alt Art 1/1s — roughly 1 in 900 packs. */
export const isTopChase = (c: Card): boolean =>
  c.rarity === "Legendary" && c.finish === "alt_art";

/** Sort a revealed pack best-card-last, for a staged reveal animation. */
export function sortForReveal(cards: Card[]): Card[] {
  const score = (c: Card) =>
    RARITY_ORDER.indexOf(c.rarity) * 10 +
    ["standard", "reverse_holo", "holo", "alt_art"].indexOf(c.finish);
  return [...cards].sort((a, b) => score(a) - score(b));
}

export const FINISH_LABEL: Record<Finish, string> = {
  standard: "Standard",
  reverse_holo: "Reverse Holo",
  holo: "Holo",
  alt_art: "Alt Art 1/1",
};

/**
 * Image paths are resolved by convention, NOT stored in cards.json —
 * baking paths into the artifact would change its hash and break the
 * published commitment.
 */
export function imageUrl(card: Card, cidBase: string): string {
  return card.finish === "standard"
    ? `${cidBase}/standard/${card.base_id}.png`
    : `${cidBase}/${card.finish}/${card.base_id}.png`;
}
