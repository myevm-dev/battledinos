#!/usr/bin/env node
/**
 * Battle Dinos Genesis — standalone verifier.
 *
 *   node verify.js <expected_manifest_hash>
 *
 * Anyone can run this against the published cards.json + packs.json to confirm
 * the set was not altered after the hash was committed. It re-derives the hash
 * and independently re-checks every supply and constraint claim. It does NOT
 * import build.js, so a rigged builder cannot make a rigged set pass.
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const OUT = path.join(__dirname, "out");
const RARITY_ORDER = ["Common", "Uncommon", "Rare", "Epic", "Legendary"];

function canonical(v) {
  if (Array.isArray(v)) return "[" + v.map(canonical).join(",") + "]";
  if (v && typeof v === "object")
    return "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + canonical(v[k])).join(",") + "}";
  return JSON.stringify(v);
}
const sha = (s) => "0x" + crypto.createHash("sha256").update(s).digest("hex");

const cards = JSON.parse(fs.readFileSync(path.join(OUT, "cards.json")));
const packs = JSON.parse(fs.readFileSync(path.join(OUT, "packs.json")));
const manifest = JSON.parse(fs.readFileSync(path.join(OUT, "manifest.json")));
const expected = process.argv[2];

const checks = [];
const ok = (label, pass, detail = "") => checks.push({ label, pass, detail });

/* -- hashes -------------------------------------------------------- */
ok("cards.json hash matches manifest", sha(canonical(cards)) === manifest.cards_hash);
ok("packs.json hash matches manifest", sha(canonical(packs)) === manifest.packs_hash);

const { manifest_hash, ...body } = manifest;
ok("manifest hash is self-consistent", sha(canonical(body)) === manifest_hash);
if (expected) {
  ok("manifest hash matches the published commitment", manifest_hash === expected,
     expected === manifest_hash ? "" : `published ${expected}\n     actual    ${manifest_hash}`);
} else {
  checks.push({ label: "published commitment", pass: null, detail: "no hash supplied — pass one as argv[2]" });
}

/* -- inventory ----------------------------------------------------- */
ok("36,000 cards", cards.length === 36000, `got ${cards.length}`);
const ids = cards.map((c) => c.token_id);
ok("token_id is 1..36000 with no gaps or repeats",
   new Set(ids).size === 36000 && Math.min(...ids) === 1 && Math.max(...ids) === 36000);
ok("token_id 1..33300 are all standard",
   cards.filter((c) => c.token_id <= 33300).every((c) => c.finish === "standard"));

const byFinish = {};
for (const c of cards) byFinish[c.finish] = (byFinish[c.finish] || 0) + 1;
for (const [f, n] of Object.entries({ standard: 33300, reverse_holo: 1767, holo: 600, alt_art: 333 })) {
  ok(`${f} count is ${n}`, byFinish[f] === n, `got ${byFinish[f] || 0}`);
}

const altByBase = {};
for (const c of cards) if (c.finish === "alt_art") altByBase[c.base_id] = (altByBase[c.base_id] || 0) + 1;
ok("every base has exactly one alt art",
   Object.keys(altByBase).length === 333 && Object.values(altByBase).every((v) => v === 1));

// edition numbering is 1..n within each (base, finish) group
const groups = {};
for (const c of cards) (groups[`${c.base_id}|${c.finish}`] ||= []).push(c);
ok("editions run 1..n within every (base, finish) group",
   Object.values(groups).every((g) => {
     const e = g.map((c) => c.edition).sort((a, b) => a - b);
     return e.every((v, i) => v === i + 1) && g.every((c) => c.edition_supply === g.length);
   }));

// per-base fields never contradict
ok("name/rarity/element are consistent within each base", (() => {
  const seen = {};
  for (const c of cards) {
    const k = c.base_id;
    if (!seen[k]) { seen[k] = c; continue; }
    if (seen[k].name !== c.name || seen[k].rarity !== c.rarity || seen[k].element !== c.element) return false;
  }
  return true;
})());

/* -- packs --------------------------------------------------------- */
ok("7,200 packs", packs.length === 7200, `got ${packs.length}`);
ok("every pack holds exactly 5 cards", packs.every((p) => p.cards.length === 5));

const dealt = packs.flatMap((p) => p.cards);
ok("every card is dealt exactly once", dealt.length === 36000 && new Set(dealt).size === 36000);

const byId = new Map(cards.map((c) => [c.token_id, c]));
ok("no pack contains a duplicate base_id",
   packs.every((p) => new Set(p.cards.map((id) => byId.get(id).base_id)).size === 5));
ok("no pack contains more than one special",
   packs.every((p) => p.cards.filter((id) => byId.get(id).finish !== "standard").length <= 1));
ok("every pack contains at least one Uncommon-or-better",
   packs.every((p) => p.cards.some((id) => RARITY_ORDER.indexOf(byId.get(id).rarity) >= 1)));

/* -- report -------------------------------------------------------- */
console.log("");
let failed = 0;
for (const c of checks) {
  const mark = c.pass === null ? "\x1b[33m  ?\x1b[0m" : c.pass ? "\x1b[32m  ✓\x1b[0m" : "\x1b[31m  ✗\x1b[0m";
  if (c.pass === false) failed++;
  console.log(`${mark} ${c.label}${c.detail ? "  \x1b[2m" + c.detail + "\x1b[0m" : ""}`);
}
console.log(failed ? `\n\x1b[31m  ${failed} CHECK(S) FAILED\x1b[0m\n` : "\n\x1b[32m  ALL CHECKS PASSED\x1b[0m\n");
process.exit(failed ? 1 : 0);
